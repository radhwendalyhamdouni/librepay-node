=== LibrePay for WooCommerce ===
Contributors: librepay-node
Tags: bitcoin, payments, woocommerce, self-hosted, non-custodial
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: AGPL-3.0

Accept Bitcoin on WooCommerce through your OWN LibrePay Node — self-hosted, non-custodial, no KYC, 0% transaction fees.

== Description ==

Connects WooCommerce to a LibrePay Node instance that YOU host. Orders are
priced in sats from the node's live BTC rate, customers pay to a unique
one-time address (stealth / BIP47 or BIP84 watch-only), and the order marks
itself paid when the transaction confirms — verified via HMAC-SHA256 signed
webhooks.

* Your node, your keys: the plugin talks only to the base URL you configure.
* No third party: nothing is sent to any vendor platform.
* Signed webhooks: payment events carry X-LibrePay-Signature (HMAC-SHA256).

== Installation ==

1. In WordPress: Plugins → Add New → Upload Plugin → choose this zip.
2. Activate "LibrePay for WooCommerce".
3. WooCommerce → Settings → Payments → "Bitcoin via LibrePay" → Enable.
4. Paste from your node's operator console (Connect your store):
   - Node API base URL (e.g. https://pay.example.com)
   - API key (lp_live_…)
   - Webhook secret
5. In the node console → "Webhook destinations" add:
   https://YOUR-SITE.com/wc-api/librepay_webhook
6. Place a test order.

== Changelog ==

= 1.0.0 =
* Initial release: on-chain + Lightning checkout, signed webhooks, refund notes.
